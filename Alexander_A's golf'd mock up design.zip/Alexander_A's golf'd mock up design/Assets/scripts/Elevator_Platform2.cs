using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Elevator_Platform2 : MonoBehaviour
{
    
    void Update()

    {

    }
    public GameObject button1;
    public button1_trigger button1n;
    void OnTriggerStay(Collider other)
    {
        
        if (other.gameObject.name.Equals("ball"))
        {
            if (button1n == true)
            {
                transform.Translate(new Vector3(0, (float)0.03, 0), Space.World);
                print("up");
            }
        }
    }
    void Start()
    {
        
    }
}
