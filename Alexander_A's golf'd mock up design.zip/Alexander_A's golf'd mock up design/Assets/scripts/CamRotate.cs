using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamRotate : MonoBehaviour
{
    // Start is called before the first frame update
    void Update()
    {
        if (Input.GetKey(KeyCode.X))
        {
            transform.Rotate(new Vector3(0, (float)0.15, 0), Space.World);
        }
        if (Input.GetKey(KeyCode.Z))
        {
            transform.Rotate(new Vector3(0, (float)-0.15, 0), Space.World);
        }
    }

    // Update is called once per frame
    void Start()
    {

    }
}
