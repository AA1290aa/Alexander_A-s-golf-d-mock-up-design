using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class button1_trigger : MonoBehaviour

{

    public bool button1n;

    void Update()
        
    {

    }

    void OnTriggerStay(Collider other)
    {
        if (other.gameObject.name.Equals("ball"))
        {


            button1n = true;
            print(button1n);
        }
    }
}
