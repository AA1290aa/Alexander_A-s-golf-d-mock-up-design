using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rigidbodyBall : MonoBehaviour
{
    public Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.velocity = new Vector3(0, 0, 0);
    }

    void Update()

    {

    }

    //void OnTriggerStay(Collider other)
    //{
        //if (other.gameObject.name.Equals("conveyor1"))
        //{

            //rb.velocity = new Vector3(10, 0 , 0);
            
        //}
        //if (other.gameObject.name.Equals("conveyor2"))
        //{

            //rb.velocity = new Vector3(10, 3, 0);

        //}
    //}
}
