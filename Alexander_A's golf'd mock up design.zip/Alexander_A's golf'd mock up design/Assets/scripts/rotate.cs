using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotate : MonoBehaviour
{
    // Start is called before the first frame update
    void Update()
    {
        if (Input.GetKey(KeyCode.E))
        {
            transform.Rotate(new Vector3(0,(float)0.05, 0), Space.Self);
        }
        if (Input.GetKey(KeyCode.Q))
        {
            transform.Rotate(new Vector3(0,(float)-0.05, 0), Space.Self);
        }
    }

    // Update is called once per frame
    void Start()
    {
        
    }
}
