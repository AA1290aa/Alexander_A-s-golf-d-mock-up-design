using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class hole9_trigger : MonoBehaviour
{

    void Update()
    {

    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name.Equals("ball"))
        {
            other.gameObject.transform.position = new Vector3((float)-18, 6, (float)-20.28);
        }

    }
}
