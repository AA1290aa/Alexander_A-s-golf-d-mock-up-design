
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movementcam : MonoBehaviour
{
    // Start is called before the first frame update
    void Update()

    {
        if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(new Vector3((float)0.005, 0, 0), Space.Self);
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(new Vector3((float)-0.005, 0, 0), Space.Self);
        }

        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(new Vector3(0, 0, (float)0.005), Space.Self);
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(new Vector3(0, 0, (float)-0.005), Space.Self);
        }
        if (Input.GetKey(KeyCode.R))
        {
            transform.Translate(new Vector3(0, (float) 0.005, 0), Space.Self);
        }
        if (Input.GetKey(KeyCode.F))
        {
            transform.Translate(new Vector3(0, (float)-0.005, 0), Space.Self);
        }


    }

    // Update is called once per frame
    void Start()
    {

    }
}
